package com.example.OneToOneExample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.OneToOneExample.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
