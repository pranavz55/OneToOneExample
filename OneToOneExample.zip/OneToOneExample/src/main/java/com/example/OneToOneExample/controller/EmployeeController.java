package com.example.OneToOneExample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.OneToOneExample.model.Employee;
import com.example.OneToOneExample.repository.EmployeeRepository;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepository emp;
	
	@PostMapping("/insertEmployee")
	public String putEmployee(@RequestBody Employee e) {
		emp.save(e);
		return "employee created";
	}
	
	
}
