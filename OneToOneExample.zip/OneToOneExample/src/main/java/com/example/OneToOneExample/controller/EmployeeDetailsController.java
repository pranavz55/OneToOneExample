package com.example.OneToOneExample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.OneToOneExample.model.Employee;
import com.example.OneToOneExample.model.EmployeeDetails;
import com.example.OneToOneExample.repository.EmployeeDetailsRepository;

@RestController
public class EmployeeDetailsController {

	@Autowired
	private EmployeeDetailsRepository empolyeeDetailsRepository;
	
	@PostMapping("/insert")
	public String putEmployeeDetails(@RequestBody EmployeeDetails e) {
		empolyeeDetailsRepository.save(e);
		return "employee details added";
	}
}
